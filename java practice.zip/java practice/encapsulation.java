 class A{
    private Double balance;
    public void setValue(Double x){
        if(x >= 0){
            balance = x;
        }else{
            System.out.println("amount is gratter than balance");
        }
    }
    public Double getValue(){
        return balance;
    }
}
public class encapsulation{
    public static void main(String[] args) {
        A r = new A();
        r.setValue(100.00);
        System.out.println(r.getValue());
        r.setValue(-100.00);
        System.out.println(r.getValue());
    }
}



//   class A{
//     private int value;
//     public void setValue(int x){
//         value = x;
//     }
//     public int getValue(){
//         return value;
//     }
//   }
//   class encapsulation{
//     public static void main(String[] args){
//         A r = new A();
//         r.setValue(100);
//         System.out.println(r.getValue());
//     }
//   }