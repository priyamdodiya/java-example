//local variable
// public class variable
// {
//     public void calc(int length,int width){
//         int area = length * width;
//         System.out.println("area is : "+area);
//     }
//     public static void main(String[] args){
//         variable obj = new variable();
//         obj.calc(4,10);
//     }
// }



//static variable
// class Counter {
//     public static int count = 0; 
//     public Counter() {
//       count++; 
//     }
//     public static void displayCount() {
//       System.out.println("Count: " + count);
//     }
//   }
//   public class variable {
//     public static void main(String[] args) {
//       Counter c1 = new Counter();
//       Counter c2 = new Counter();
//       Counter.displayCount(); 
//     }
//   }

