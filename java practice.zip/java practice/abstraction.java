// abstract class Student{
//     abstract void Tirth();
// }

// class Karan extends Student{
//     void Tirth(){
//         System.out.println("mt name is tirth");
//     }
// }

// class Sagar extends Student{
//     void Tirth(){
//         System.out.println("mt name is Sagar");
//     }
// }

// class abstraction{
//     public static void main(String[] args) {
//         Student obj1 = new Karan();
//         obj1.Tirth();
//         Student obj3 = new Sagar();
//         obj3.Tirth();
//     }
// }

