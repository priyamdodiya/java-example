import java.util.*;
public class withoutscanner

{
    public static void main(String n[]){
        
        System.out.println("hello"+n[0]);
       
    }
}