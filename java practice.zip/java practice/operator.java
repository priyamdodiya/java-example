
// public class operator {

//     public static void main(String[] args) {
//         int a = 10;
//         int b = 20;
//         int c = a + b;
//         int d = a - b;
//         // a--;
//         // b++;
//         --a;
//         ++a;
//         System.out.println("sum of this number : " + c);
//         System.out.println("sum of this number : " + d);
//         System.out.println("sum of this number : " + a);
//         System.out.println("sum of this number : " + b);
//     }
// }


public class operator {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        for (int number : numbers) {
            if (number % 2 == 0) {
                continue;
            }
            System.out.print( " "+ number );
        }
    }
}