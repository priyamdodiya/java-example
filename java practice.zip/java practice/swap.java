import java.util.Scanner;
public class swap{
public static void main(String[] args){
    Scanner sc = new Scanner(System.in);
    System.out.println("enter first number : ");
    int a = sc.nextInt();
    System.out.println("enter second number : ");
    int b = sc.nextInt();
    int swaped = a;
    a = b;
    b = swaped;
    System.out.println("first is number : "+a);
    System.out.println("second is number : "+b);
    System.out.println();
    System.out.println("enter number find factorial : ");
    int n = sc.nextInt();
    int factorial = 1;
    for(int i = 1; i<=n; i++){
        factorial *= i;
    }
    System.out.println("factorial of : "+n+" is : "+factorial);
}
}