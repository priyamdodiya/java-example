import java.util.Scanner;

public class FindFactorial1a {
    public static void main(String[] args) {
        int number, i, fact = 1;
        Scanner num = new Scanner(System.in);
        System.out.println("Enter the value for which you want to find the factorial: ");
        number = num.nextInt();
        for (i = 1; i <= number; i++) {
            fact = fact * i;
        }
        System.out.println("Factorial of "+number+" is: "+fact);
    }
}
