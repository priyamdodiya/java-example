import javax.sound.midi.Soundbank;

public class Patterns2b
{
    public static void numberTrianglePattern(int n)
    {
        int i, j;
        for (i = 1; i <= n; i++)
        {
            for (j = 1; j <= n - i; j++)
            {
                System.out.print(" ");
            }
            for (j = 1; j <= i; j++)
            {
                System.out.print(i + " ");
            }
            System.out.println();
        }
    }
    public static void rightHalfPyramidPattern(int n) {
        int i, j;
        int num = 1;
        for (i = 1; i <= n; i++)
        {
            for (j = 1; j <= i; j++)
            {
                System.out.print("*");
                num++;
            }
            System.out.println();
        }
    }
    public static void leftHalfPyramidPattern(int n)
    {
        int i, j;
        for(i=0; i<n; i++)
        {
            for(j=2*(n-i); j>=0; j--)
            {
                System.out.print(" ");
            }
            for(j=0; j<=i; j++)
            {
                System.out.print("* ");
            }
            System.out.println();
        }
    }
    public static void ReverseRightPattern(int n)
    {
        int i, j;
        for (i = n; i >= 1; i--) {
            for (j = 1; j <= i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
    public static void starTrianglePattern(int n)
    {
        int i, j;
        for (i = 1; i <= n; i++)
        {
            for (j = 1; j <= n - i; j++)
            {
                System.out.print(" ");
            }
            for (j = 1; j <= i; j++)
            {
                System.out.print("* ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args)
    {
        int n = 6;
        System.out.println("Number Triangle Pattern:");
        numberTrianglePattern(n);
        System.out.println("\nRight Half Pyramid Pattern:");
        rightHalfPyramidPattern(n);
        System.out.println("\nLeft Half Pyramid Pattern:");
        leftHalfPyramidPattern(n);
        System.out.println("Reverse Right Pattern:");
        ReverseRightPattern(n);
        System.out.println("Triangle Star Pattern:");
        starTrianglePattern(n);
    }
}
