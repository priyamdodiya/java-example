import java.util.Scanner;

public class CheckOddEven1b
{
    public static void main(String[] args)
    {
        int num;
        Scanner val = new Scanner(System.in);
        System.out.println("Enter the number for which you want to find an odd or even:");
        num = val.nextInt();
        if (num%2 == 0)
        {
            System.out.println("Given number: "+num+" is even.");
        }
        else
        {
            System.out.println("Given number: "+num+" is odd.");
        }
    }
}
