import java.util.Scanner;

public class CheckPalindrome2a
{
    public static void main(String[] args)
    {
        int r ,sum=0,temp, n;
        Scanner val = new Scanner(System.in);
        System.out.println("Enter the number to check weather the given number is palindrome or not");
        n = val.nextInt();
        temp=n;
        while(n>0){
            r=n%10;  //getting remainder
            sum=(sum*10)+r;
            n=n/10;
        }
        if(temp==sum)
            System.out.println(temp+" is palindrome number ");
        else
            System.out.println(temp+" is not palindrome");
    }
}
