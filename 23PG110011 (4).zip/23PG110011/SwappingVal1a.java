import java.util.Scanner;

public class SwappingVal1a {
    public static void main(String[] args) {
        int a, b, temp;
        Scanner val1 = new Scanner(System.in);
        Scanner val2 = new Scanner(System.in);
        System.out.println("Enter value for a:");
        a = val1.nextInt();
        System.out.println("Enter value for b:");
        b = val2.nextInt();
        System.out.println("Before swapping a = "+a);
        System.out.println("Before swapping b = "+b);
        temp = a;
        a = b;
        b = temp;
        System.out.println("After swapping a = "+a);
        System.out.println("After swapping b = "+b);
    }
}
