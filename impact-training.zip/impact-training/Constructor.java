// public class Cat {
//     private String name;
//     private int age;

//     public Cat() {
//         this.name = "Whiskers";
//         this.age = 2;
//     }

//     public void meow() {
//         System.out.println(name + " is meowing!");
//     }

//     public static void main(String[] args) {
//         Cat myCat = new Cat();
//         System.out.println("My cat's name is " + myCat.name + " and he is " + myCat.age + " years old.");
//         myCat.meow();
//     }
// }




// public class Bird {
//     private String name;
//     private int age;

//     public Bird(String name, int age) {
//         this.name = name;
//         this.age = age;
//     }

//     public Bird() {
//         this.name = "Tweety";
//         this.age = 1;
//     }

//     public void chirp() {
//         System.out.println(name + " is chirping!");
//     }

//     public static void main(String[] args) {
//         Bird birdWithParams = new Bird("Polly", 4);

//         Bird birdWithoutParams = new Bird();

//         System.out.println("My bird's name is " + birdWithParams.name + " and it is " + birdWithParams.age + " years old.");
//         birdWithParams.chirp();

//         System.out.println("My bird's name is " + birdWithoutParams.name + " and it is " + birdWithoutParams.age + " years old.");
//         birdWithoutParams.chirp();
//     }
// }



//null pointer exception
// public class Constructor {
//     public static void main(String[] args) {
//         String str = null;
        
//         if (str != null) {
//             System.out.println(str.length());
//         } else {
//             System.out.println("The string is null.");
//         }
//     }
// }