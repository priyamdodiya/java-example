//syncronized example of multithreaking in java

public class SynchronizedExample {
    private int count = 0;

    public synchronized void increment() {
        count++;
    }
    public static void main(String[] args) {
        SynchronizedExample example = new SynchronizedExample();
        Thread thread = new Thread(() -> {
            example.increment();
        });
        thread.start();
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Final count: " + example.count);
    }
}