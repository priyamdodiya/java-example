//by creating thread class

// public class MyThread extends Thread {
//     public void run() {
//       System.out.println("This is running in a separate thread!");
//     }
  
//     public static void main(String[] args) {
//       MyThread thread = new MyThread();
//       thread.start();
//     }
//   }
  

//by implementing runnable interface
public class MyThread implements Runnable {
  public void run() {
    System.out.println("This is running in a separate thread!");
  }

  public static void main(String[] args) {
    MyThread runnable = new MyThread();
    Thread thread = new Thread(runnable);
    thread.start();
  }
}