// public class DelayedPrinting implements Runnable {
//     public void run() {
//         try {
//             Thread.sleep(5000);
//             System.out.println("Printing after 5 seconds.");
//         } catch (InterruptedException e) {
//             e.printStackTrace();
//         }
//     }

//     public static void main(String[] args) {
//         Thread thread = new Thread(new DelayedPrinting());
//         thread.start();
//     }
// }

