//example of the add method
// import java.util.ArrayList; 
// public class arraymethod { 
// public static void main(String[] args) 
// 	{  
// 		ArrayList<Integer> arrlist = new ArrayList<Integer>(5); 
// 		arrlist.add(15); 
// 		arrlist.add(20); 
// 		arrlist.add(25); 
// 		for (Integer number : arrlist) { 
// 			System.out.println("Number = " + number); 
// 		} 
// 	} 
// } 


// Java program to Remove Elements from ArrayList 
// import java.util.ArrayList; 
// import java.util.List; 
// public class arraymethod { 
// 	public static void main(String[] args) 
// 	{ 
// 		List<Integer> al = new ArrayList<>(); 
// 		al.add(10); 
// 		al.add(20); 
// 		al.add(30); 
// 		al.add(1); 
// 		al.add(2); 
// 		System.out.println(al); 
// 		al.remove(1); 
// 		al.remove(1); 
// 		System.out.println(al); 
// 	} 
// }



// contains() method in ArrayList
import java.util.ArrayList;
class arraymethod {
	public static void main(String[] args)
	{
		ArrayList<Integer> arr = new ArrayList<Integer>(4);
		arr.add(1);
		arr.add(2);
		arr.add(3);
		arr.add(4);
		boolean ans = arr.contains(2);
		if (ans)
			System.out.println("The list contains 2");
		else
			System.out.println("The list does not contains 2");
		ans = arr.contains(5);
		if (ans)
			System.out.println("The list contains 5");
		else
			System.out.println("The list does not contains 5");
	}
}