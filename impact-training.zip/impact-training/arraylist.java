import java.util.ArrayList;

public class arraylist {

    public static void main(String[] args) {

        ArrayList<String> fruits = new ArrayList<>();

        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Orange");

        System.out.println("Original fruits list: " + fruits);

        // Remove element by index (removes "Banana")
        fruits.remove(1);
        System.out.println("Fruits after removing element at index 1: " + fruits);

        // Remove element by value (removes "Orange" if present)
        fruits.remove("Orange");
        System.out.println("Fruits after removing element 'Orange': " + fruits);

        // Set element at index 0 (replaces "Apple" with "Mango")
        fruits.set(0, "Mango");
        System.out.println("Fruits after setting element at index 0: " + fruits);
    }
}