import java.util.Arrays;
public class largethirdarray {
    public static void main(String[] args) {
        int[] arr = {10, 2, 5, 7, 9, 12, 1};
        Arrays.sort(arr);
        if (arr.length < 3) {
            System.out.println("Array has less than three elements.");
        } else {
            System.out.println("The third largest number is: " + arr[arr.length - 3]);
        }
    }
}
