import java.util.Arrays;

public class largesecondarray {

    public static void main(String[] args) {
        int[] arr = {10, 2, 5, 7, 9, 12, 1};
        Arrays.sort(arr);
        if (arr.length < 2) {
            System.out.println("Array has less than two elements.");
        } else {
            System.out.println("The second largest number is: " + arr[arr.length - 2]);
        }
    }
}