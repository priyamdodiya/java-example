//give me example of thread priority max prority and min prority and four 
//thread create and execute a first thread give me example in java very small example 
public class ThreadPriorityExample {
    public static void main(String[] args) {
        Thread maxPriorityThread = new Thread(new MyRunnable(), "MaxPriorityThread");
        maxPriorityThread.setPriority(Thread.MAX_PRIORITY);
        maxPriorityThread.start();

        Thread highPriorityThread = new Thread(new MyRunnable(), "HighPriorityThread");
        highPriorityThread.setPriority(Thread.NORM_PRIORITY + 1);
        highPriorityThread.start();

        Thread normalPriorityThread = new Thread(new MyRunnable(), "NormalPriorityThread");
        normalPriorityThread.setPriority(Thread.NORM_PRIORITY);
        normalPriorityThread.start();

        Thread minPriorityThread = new Thread(new MyRunnable(), "MinPriorityThread");
        minPriorityThread.setPriority(Thread.MIN_PRIORITY);
        minPriorityThread.start();
    }
}

class MyRunnable implements Runnable {
    public void run() {
        System.out.println("Thread: " + Thread.currentThread().getName() +
                ", Priority: " + Thread.currentThread().getPriority());
    }
}                               