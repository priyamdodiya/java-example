//write a java program to count no of word in a given string 
class WordCountException extends Exception {
    public WordCountException(String message) {
        super(message);
    }
}
public class First {
    public static void main(String[] args) {
        String str = "this is example for the java program";
        try {
            int wordCount = countWords(str);
            System.out.println("Total number of words in the given string are: " + wordCount);
        } catch (WordCountException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
    public static int countWords(String str) throws WordCountException {
        if (str == null || str.isEmpty()) {
            throw new WordCountException("Input string is null or empty.");
        }
        String[] words = str.split("\\s+");
        return words.length;
    }
}