// public class pattern{
//     public static void main(String[] args){
//        int rows = 10;
//        for(int i=1; i<=rows; i++){
//         for(int j = 1; j<=rows-i; j++){
//             System.out.print(" ");
//         }
        
//         for(int k = 1; k<= i; k++){
//             System.out.print("*");
//         }
//         System.out.println();
//        }
//     }
// }



//     //    int i, j;
//     //    int rows = 5;
//     //    for(i = 1; i <= rows; i++){
//     //     for(j=1; j<=rows-i; j++){
//     //         System.out.print(" ");
//     //     }
//     //     for(int k =1; k<=i; k++){
//     //         System.out.print("* ");
//     //     }
//     //     System.out.println();
//     //    }



//         // int i,j;
//         // int num = 1;
//         // int rows = 5;
//         // for(i=1; i<=rows;i++){
//         //     for(j=1; j<=i; j++){
//         //         System.out.print(num+" ");
//         //         num++;
//         //     }
//         //     System.out.println();
//         // }

//     }
// }



// import java.util.HashMap;
// import java.util.Map;

// public class pattern {
//     public static void main(String[] args) {
//         String inputString = "hello world";
//         Map<Character, Integer> charCountMap = new HashMap<>();
//         for (char c : inputString.toCharArray())
//             charCountMap.put(c, 1 + charCountMap.getOrDefault(c, 0));
//         System.out.println(charCountMap);
//     }
// }



// public class pattern {
//     public static void main(String[] args) {
//         try {
//             int a = 10;
//             int b = 0;
//             int result1 = a / b;
//             System.out.println("Result 1: " + result1);
//         } catch (ArithmeticException e) {
//             System.out.println("ArithmeticException caught: Division by zero!");
//         } 
//         try {
//             int[] numbers = {1, 2, 3};
//             int index = 3;
//             int result2 = numbers[index];
//             System.out.println("Result 2: " + result2);
//         } catch (ArithmeticException e) {
//             System.out.println("ArithmeticException caught!");
//         }
//     }
// }