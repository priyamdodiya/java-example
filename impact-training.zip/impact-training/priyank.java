// import java.util.*;
// public class priyank

// {
//     public static void main(String n[]){
        
//         System.out.println("hello"+n[0]);
       
//     }
// }


// public class priyank{
//     static int a = 64;
//     public static void main(String[] args){
//         char c = (char) a;
//         System.out.println(c);
//     }
// }


public class priyank {  
    static char a = ':'; 

    public static void main(String[] args) {
        int c = a;  
        System.out.println(c);
    }
}