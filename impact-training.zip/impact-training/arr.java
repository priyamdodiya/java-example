public class arr {
    public static void main(String[] args) {
        int[] numbers = {10, 20, 30, 40, 50};

        System.out.println("Element at index 0: " + numbers[0]);
        System.out.println("Element at indelement at index 1: " + numbers[1]);

        int length = numbers.length;
        System.out.println("Length of the array: " + length);

        System.out.println("All elements of the array:");
        for (int i = 0; i < numbers.length; i++) {
            System.out.println("Element at index " + i + ": " + numbers[i]);
        }
    }
}



// public class arr {
//     public static void main(String[] args) {
//         int[][] matrix = {
//             {1, 2, 3},
//             {4, 5, 6},
//             {7, 8, 9}
//         };
//         System.out.println("Element at row 0, column 0: " + matrix[0][0]);
//         System.out.println("Element at row 1, column 2: " + matrix[1][2]);
//         matrix[1][1] = 10;
//         System.out.println("Modified element at row 1, column 1: " + matrix[1][1]);
//         int numRows = matrix.length;
//         int numCols = matrix[0].length;
//         System.out.println("Number of rows in the array: " + numRows);
//         System.out.println("Number of columns in the array: " + numCols);
//         System.out.println("All elements of the array:");
//         for (int i = 0; i < numRows; i++) {
//             for (int j = 0; j < numCols; j++) {
//                 System.out.println("Element at row " + i + ", column " + j + ": " + matrix[i][j]);
//             }
//         }
//     }
// }




// public class arr {
//     public static void main(String[] args) {

//         int[][][] threeDArray = {
//             { {1, 2, 3}, {4, 5, 6}, {7, 8, 9} },
//             { {10, 11, 12}, {13, 14, 15}, {16, 17, 18} },
//             { {19, 20, 21}, {22, 23, 24}, {25, 26, 27} }
//         };

//         for (int i = 0; i < threeDArray.length; i++) {
//             for (int j = 0; j < threeDArray[i].length; j++) {
//                 for (int k = 0; k < threeDArray[i][j].length; k++) {
//                     System.out.println("Element at [" + i + "][" + j + "][" + k + "]: " + threeDArray[i][j][k]);
//                 }
//             }
//         }
//     }                                                  
// }
